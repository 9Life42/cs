#include <FPT.h>

int main()
{
  outS("Hello World!\n") ;
}
