
#include <stdio.h>
#include <Non_graphics.h>

int main()
{
  double x ;
  int i ;

  scanf("%lf",&x) ;
  i = mki(x) ;
  printf("x = %lf, i = %d\n",x,i) ;

}
