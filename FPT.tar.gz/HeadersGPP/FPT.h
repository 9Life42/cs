

#ifndef FPT__1234abcd__5678xyz
#define FPT__1234abcd__5678xyz

using namespace std ;
#include <iostream>
#include <iomanip>






#include <stdio.h>
#include <math.h>
#include <stdlib.h> // drand48, atoi
#include <unistd.h> // usleep
#include <time.h> // for G_get_time stuff
#include <sys/time.h> 
#include <string.h> // strcpy, strcat, etc

#include <Non_graphics.h>


#include <G_graphics.h>


#include <X_graphics.h>  
      // change this if you have a different underlying
      // system such as windows

#endif
